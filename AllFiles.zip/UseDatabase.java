import java.io.*;

public class UseDatabase {
    static public void main(String a[]) throws IOException {
//        (new Database()).run(new Personal());
        (new Database()).run(new Student());
    }
}
